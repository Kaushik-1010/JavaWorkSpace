package com.NaturnalNumbersInReverseOrder;

import java.util.*;
public class SumOfNaturalNumbersInGivenRange {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		//int sum=0;
		//for(int i=a;i<=b;i++)
		//{
			//sum+=i;
		//}
		//System.out.println("Sum from "+a+" to "+b+" is "+sum); //T(n)= O(n)
		System.out.println(b*(b+1)/2-a*(a+1)/2+a);
		

	}

}
