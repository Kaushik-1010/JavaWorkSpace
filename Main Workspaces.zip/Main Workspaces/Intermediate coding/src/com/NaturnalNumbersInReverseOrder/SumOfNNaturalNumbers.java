package com.NaturnalNumbersInReverseOrder;

import java.util.*;
public class SumOfNNaturalNumbers {

	public static void main(String[] args) {
		//int sum=0;
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		//for(int i=0;i<=n;i++)
		//{
			//sum+=i;
		//}
		//System.out.println(sum); //Time complexity is O(n)
		
		System.out.println(n*(n+1)/2);  //Time complexity is O(1)
	}

}
