package com.Top100Codes;

import java.util.Scanner;

public class HCFMethod2 {
    public static int Hcf(int a, int b)
    {
        if(a==0)
            return b;
        if(b==0)
            return a;
        if(a==b)
            return a;
        if(a>b)
            return Hcf(a-b,b);
        else
            return Hcf(a,b-a);
    }
    public static void main(String args [])
    {
        Scanner sc= new Scanner(System.in);
        int n1= sc.nextInt();
        int n2= sc.nextInt();
        System.out.println(Hcf(n1,n2));
    }
}
