package com.Top100Codes;

import java.util.Scanner;

public class BinaryToDecimalConversion {
    public static void main(String args [])
    {
        Scanner sc=new Scanner(System.in);
        long binary= sc.nextLong();
        long rem=0;
        long n=0;
        while(binary>0)
        {
            long temp= binary%10;
            rem += temp * Math.pow(2, n);
            binary=binary/10;
            n++;
        }
        System.out.println("Decimal Number : "+rem);


    }
}
