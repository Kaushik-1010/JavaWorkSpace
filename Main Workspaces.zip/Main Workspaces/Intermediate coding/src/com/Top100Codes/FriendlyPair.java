package com.Top100Codes;

import java.util.*;
public class FriendlyPair {
    public static void main(String args[]) {
        Scanner sc=new Scanner(System.in);
        int num1= sc.nextInt();
        int num2= sc.nextInt();
        int temp1=num1;
        int temp2=num2;
        int sum1=0,sum2=0;
        for(int i=1;i<temp1;i++)
        {
            if(temp1%i==0)
            {
                sum1=sum1+i;
            }
        }
        for(int j=1;j<temp2;j++)
        {
            if(temp2%j==0)
            sum2=sum2+j;
        }
        if((sum1==num1) && (sum2==num2))
        {
            System.out.println("Friendly Pair");
        }
        else
        {
            System.out.println("Not a Friendly Pair");
        }
    }
}
