package com.Top100Codes;

import java.util.*;
public class AutoTropicNumber
{
    public static void main(String args[])
    {
        Scanner sc= new Scanner(System.in);
        int num=sc.nextInt();
        int d;
        int tot=0;
        int temp=num;
        d=temp%10;
        int temp2=num;
        tot=temp2*temp2;
        int d2=tot%10;
        if(d==d2)
        {
            System.out.println("AutoTropic Number");
        }
        else
        {
            System.out.println("It is not AutoTropic Number");
        }


    }
}
