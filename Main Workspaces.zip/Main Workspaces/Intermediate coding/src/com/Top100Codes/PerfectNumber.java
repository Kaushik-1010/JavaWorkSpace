package com.Top100Codes;

import java.util.*;
public class PerfectNumber {
    public static void main(String args[]) {
        Scanner sc= new Scanner(System.in);
        int num= sc.nextInt();
        int tot=0;
        int temp=num;
        int i=1;
        while(i<temp) {
            if(temp%i==0)
            {
                tot=tot+i;
            }
            i++;
        }
        if(tot==num)
        {
            System.out.println("It is Perfect Number");
        }
        else {
            System.out.println("It is not a Perfect Number");
        }
    }
}