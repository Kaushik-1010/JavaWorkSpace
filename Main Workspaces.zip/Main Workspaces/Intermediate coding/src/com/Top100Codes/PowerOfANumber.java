package com.Top100Codes;

import java.util.*;
public class PowerOfANumber {
    public static void main(String args[]) {
        Scanner sc=new Scanner(System.in);
        int base=sc.nextInt();
        int exp=sc.nextInt();
        int res=1;
        while(exp>0)
        {
            res=res*base;
            --exp;
        }
        System.out.println(res);
    }
}
