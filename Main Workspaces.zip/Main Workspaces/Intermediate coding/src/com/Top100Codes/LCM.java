package com.Top100Codes;

import java.util.Scanner;

public class LCM {
    public static int gcd(int a, int b) { // GCD is also known as HCF
        if (b == 0) return a;
        return gcd(b, a % b);
    }

    public static int lcm(int a, int b) {
        return (a * b) / gcd(a, b);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the first number: ");
        int n1 = sc.nextInt();
        System.out.print("Enter the second number: ");
        int n2 = sc.nextInt();
        if (n1 <= 0 || n2 <= 0) {
            System.out.println("Both numbers must be positive integers.");
            return;
        }
        System.out.println("The LCM of " + n1 + " and " + n2 + " is " + lcm(n1, n2));
    }
}
