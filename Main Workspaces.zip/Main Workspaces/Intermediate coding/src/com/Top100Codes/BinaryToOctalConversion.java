package com.Top100Codes;

import java.util.Scanner;

public class BinaryToOctalConversion {
    public static void main(String args []) {
        Scanner sc= new Scanner(System.in);
        int binary= sc.nextInt();
        int decimal=0;
        int n=0;
        while(binary>0)
        {
            int temp=binary%10;
            decimal+=temp+Math.pow(2,n);
            binary=binary/10;
            n++;

        } //The Binary number is converted into decimal number
            //Now we need to convert this decimal number into octal number
        int[] oct =new int[20];
        int i=0;
        while(decimal>0)
        {
            int rem=decimal%8;
            oct[i++]=rem;
            decimal=decimal/8;
        }
        System.out.print("Octal Number: ");
        for(int j=i-1;j>=0;j--)
        {
            System.out.print(oct[j]);
        }
    }
}
