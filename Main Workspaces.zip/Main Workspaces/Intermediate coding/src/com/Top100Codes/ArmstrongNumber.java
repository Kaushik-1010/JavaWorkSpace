package com.Top100Codes;

import java.util.*;
public class ArmstrongNumber {
    public static void main(String args[]) {
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    int sum=0;
    int d;
    int temp=n;
    while(temp>0) {
        d=temp%10;
        sum=sum+(d*d*d);
        temp=temp/10;
    }
    if(sum==n)
        System.out.println(" a armstrong number");

}}
