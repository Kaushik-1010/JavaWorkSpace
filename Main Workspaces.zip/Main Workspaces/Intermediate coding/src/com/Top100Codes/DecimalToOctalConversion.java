package com.Top100Codes;

import java.util.Scanner;
public class DecimalToOctalConversion {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int decimal= sc.nextInt();

    }
}
