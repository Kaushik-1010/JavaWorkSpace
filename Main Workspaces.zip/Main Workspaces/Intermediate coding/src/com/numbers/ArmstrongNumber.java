package com.numbers;

import java.util.*;
public class ArmstrongNumber {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int len;
		len=order(n);
		if(isArmstrong(n,len))
			System.out.println(n+" is a armstrong number");
		else
			System.out.println(n+" is not armstrong number");
				

	}
	public static int order(int n)
	{
		int len=0;
		while(n>0)
		{
			len+=1;
			n=n/10;
		}
		return len;
	}
	public static boolean isArmstrong(int n,int len)
	{
		int digit,sum=0,temp;
		temp=n;
		while(temp>0)
		{
			digit=temp%10;
			sum=sum+(int)(Math.pow(digit,len));
			temp/=10;
		}
		return n==sum;
	}

}
