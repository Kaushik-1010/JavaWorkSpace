package com.numbers;

import java.util.*;
public class PalindromeNumber {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int org_num=sc.nextInt();
		int rev_num=0,rem;
		int temp=org_num; //This is very imp
		while(temp>0)
		{
			rem=temp%10;
			rev_num=rev_num*10+rem;
			temp=temp/10;
		}
		if(org_num==rev_num)
			System.out.println(org_num+" is a palindrome number");
		else
			System.out.println(org_num+" is not palindrome number");
		

	}

}
