package com.numbers;

import java.util.*;
public class BinaryToDecimal {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		long num=sc.nextLong();
		System.out.println(convert(num));

	}
	public static long convert(long num)
	{
		int i=0,decimal=0;
		while(num>0)
		{
			long digit=num%10;
			decimal+=digit*Math.pow(2,i); //for Octal to decimal use the same with Math.pow(8,i)
			num=num/10;
			i++;
		}
		return decimal;
	}

}
