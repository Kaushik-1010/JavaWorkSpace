package com.numbers;

import java.util.*;
public class BinaryToDecimalUsingLibraryFunction {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String binary=sc.nextLine();
		System.out.println(Integer.parseInt(binary,2));
		

	}

}
