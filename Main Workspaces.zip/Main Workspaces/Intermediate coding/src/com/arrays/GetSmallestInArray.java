package com.arrays;

public class GetSmallestInArray {

	public static void main(String[] args) {
		int []arr= {2,5,1,8,9};
		System.out.println("The smallest element in array is "+getSmallest(arr));
	}
	public static int getSmallest(int []arr)
	{
		int min=arr[0];
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]<min)
			{
				min=arr[i];
				
			}
		}
		return min;
	}

}
