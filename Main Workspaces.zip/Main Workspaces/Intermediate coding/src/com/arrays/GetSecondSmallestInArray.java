package com.arrays;

public class GetSecondSmallestInArray {

	public static void main(String[] args) {

		int []arr= {1,2,5,9,3,8};
		System.out.println("The Second smallest element in array is "+getSecondSmallest(arr));
	}
	public static int getSecondSmallest(int []arr)
	{
		int min=arr[0];
		if(arr.length<2) //CONDITION IF ARRAY HAS LESS THAN 2 ELEMENTS
		{
		System.out.println("Array has less than 2 elements");
		return arr[0];
		}
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]<min)
			{
				min=arr[i];
				
			}
		}
		int second_min=Integer.MAX_VALUE;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]!=min && arr[i]<second_min)
				second_min=arr[i];
		}
		return second_min;
	}}

