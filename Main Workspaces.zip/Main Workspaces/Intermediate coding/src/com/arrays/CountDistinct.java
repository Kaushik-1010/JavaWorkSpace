package com.arrays;

public class CountDistinct {

	public static void main(String[] args) {
		int []arr= {5,8,5,7,8,10};
		int n=arr.length;
		System.out.println(countDistinct(arr,n));

	}
	public static int countDistinct(int []arr,int n)
	{
		int count=0;
		for(int i=0;i<n;i++)
		{
			int flag=0;
			for(int j=i+1;j<n;j++)
			{
				if(arr[i]==arr[j])
				{
					flag=1;
				break;
			}
		}
		if(flag==0)
			count++;
	}
		return count;
// Time complexity= O(n^2)
		//Space= O(1)
}
}


