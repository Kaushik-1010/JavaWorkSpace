package com.arrays;

public class LinearSearch {

	public static void main(String[] args) {
		int []arr= {23,22,1,2,7,9};
		int item=1;
		LinearSearch(arr,item);
		
	}
	public static void LinearSearch(int []arr,int item)
	{
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==item)
			{
				System.out.println(item+" Found at Index "+i);
				return;
			}
			
		}
		System.out.println("Not Found");
	}

}
