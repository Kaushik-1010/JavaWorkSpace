package cylinder;

public class Cylinder {
	private double radius;
	private double height;
	public double getRadius() {
		return radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public double getDimensions()
	{
		return radius,height;
	}
	public void setDimensions(double r, double h)
	{
		this.radius=r;
		this.height=h;
	}
}
