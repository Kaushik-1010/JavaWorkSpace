package rectangletest;

public class Rectangle {
	private int length;
	private int breadth;
	public Rectangle()
	{
		length=1;
		breadth=1;
	}
	public Rectangle(int l,int b)
	{
		length=l;
		breadth=b;
	}
	public Rectangle(int s)
	{
		length=breadth=s;
	}

}
