package com.DSA.Stacks;

import java.util.*;
public class Example {
    public static void main(String[] args) {

        int Arr[][] = { {0, 20, 5, 4} };
        int Arr2[][] = { {0, 20, 5, 4 } } ;
        System.out.println(Arrays.deepEquals(Arr, Arr2));
        }
    }

