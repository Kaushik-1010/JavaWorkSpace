package power;
import java.util.*;
public class Power {
	public int power(int b, int e) {
		if(e<0) {
			return -1;
		}
		if(e==0) {
			return 1;
		}
		return b*power(b,e-1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int b=sc.nextInt();
		int e=sc.nextInt();
		Power p=new Power();
		System.out.println(p.power(b, e));
		
		

	}

}
