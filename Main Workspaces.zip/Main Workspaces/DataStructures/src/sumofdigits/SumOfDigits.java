package sumofdigits;
import java.util.*;
public class SumOfDigits {
	public int sumDigits(int n) {
		if(n<0 || n==0)
		{
			return 0;
		}
		
		return n%10 + sumDigits(n/10);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		SumOfDigits s= new SumOfDigits();
		System.out.println(s.sumDigits(n));

	}

}
