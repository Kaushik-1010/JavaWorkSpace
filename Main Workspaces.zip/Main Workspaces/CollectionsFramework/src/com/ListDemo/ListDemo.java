package com.ListDemo;

import java.util.*;
public class ListDemo {

	public static void main(String[] args) {
			ArrayList<Integer> a1= new ArrayList<>();
			ArrayList<Integer> a2= new ArrayList<>(List.of(50,60,70,80,90));
			
			a1.add(10);
		     a1.add(0,5);
		     //a1.addAll(a2);
		     a1.addAll(1,a2);
		     a1.add(5,70);
		     a1.add(6,100);
		     //System.out.println(a1);
		     //a1.forEach(n->show(n));
		     //a1.forEach(System.out::println);
		     //System.out.println(a1.contains(50));
		     

	}
	static void show(int n)
	{
		if(n>50)
		System.out.println(n);
	}

}
