package com.DequeDemo;

import java.util.*;
public class DequeDemo {
	
	
	public static void main(String[] args) {
		ArrayDeque<Integer> dq= new ArrayDeque<>();
		/*dq.offerFirst(10);
		dq.offerFirst(20);
		dq.offerFirst(30);
		dq.offerFirst(40);
		dq.offerFirst(50);*/
		dq.forEach((x)->System.out.print(x+" "));
		
		

	}

}
