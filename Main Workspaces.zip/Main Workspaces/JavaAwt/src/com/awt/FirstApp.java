package com.awt;

import java.awt.*;
public class FirstApp {
    public static void main(String args[]) {
        Frame f=new Frame("This is my First App");
        f.setSize(300,300);
        f.setVisible(true);
    }
}
